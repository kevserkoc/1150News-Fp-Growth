from mlxtend.frequent_patterns import fpgrowth
from mlxtend.preprocessing import TransactionEncoder
import os
import string
import pandas as pd
import chardet

# Kategoriler ve dosya isimleri
kategori_klasorleri = [ "saglik", "ekonomi", "siyasi", "spor"]
veri_kok_dizini = "r"  # Ana veri klasörü

a = []

# Her kategorideki metinleri okuma ve a listesine ekleme
for kategori in kategori_klasorleri:
    kategori_yolu = os.path.join(veri_kok_dizini, "raw_texts", kategori)
    dosyalar = os.listdir(kategori_yolu)
    for dosya in dosyalar:
        dosya_yolu = os.path.join(kategori_yolu, dosya)

        # Dosyanın kodlamasını belirleme
        with open(dosya_yolu, 'rb') as f:
            result = chardet.detect(f.read())
            encoding = result['encoding']

        # Dosyayı belirlenen kodlama ile açma
        with open(dosya_yolu, "r", encoding=encoding) as f:
            # Noktalama işaretlerini çıkarma ve kelimeleri virgül ile ayırma
            kelimeler = f.read().lower().translate(str.maketrans('', '', string.punctuation)).split()
            a.append(kelimeler)
            print(f"Kelime ayıklanan dosya: {dosya}")
            print("Ayıklanan kelimeler:", kelimeler)
            print("---------------")

# Veriyi TransactionEncoder'a uygun formata getirme
te = TransactionEncoder()
te_ary = te.fit_transform(a)
df = pd.DataFrame(te_ary, columns=te.columns_)

# FP-Growth algoritması ile sık kalıpları bulma
frequent_itemsets_2 = fpgrowth(df, min_support=0.5, use_colnames=True, max_len=2)
frequent_itemsets_3 = fpgrowth(df, min_support=0.5, use_colnames=True, max_len=3)
frequent_itemsets_4 = fpgrowth(df, min_support=0.5, use_colnames=True, max_len=4)

print("En sık kullanılan 2 kelimeler:")
print(frequent_itemsets_2)

print("\nEn sık kullanılan 3 kelimeler:")
print(frequent_itemsets_3)

print("\nEn sık kullanılan 4 kelimeler:")
print(frequent_itemsets_4)
