from mlxtend.frequent_patterns import fpgrowth
from mlxtend.preprocessing import TransactionEncoder
import os
import string
import pandas as pd
from collections import defaultdict

kategori_klasorleri = ["magazin", "saglik", "ekonomi", "siyasi", "spor"]
veri_kok_dizini = "1150Haber/r"  # Ana veri klasörü

a = []
noktalama_isaretleri_silindi = defaultdict(list)

magazin_ilk_metin = None
magazin_ilk_temizlenmis_metin = None

for kategori in kategori_klasorleri:
    kategori_yolu = os.path.join(veri_kok_dizini, "raw_texts", kategori)
    dosyalar = os.listdir(kategori_yolu)
    for dosya in dosyalar:
        dosya_yolu = os.path.join(kategori_yolu, dosya)
        with open(dosya_yolu, "r") as f:
            metin = f.read().lower()
            orijinal_metin = metin  # Orijinal metni sakla
            silinen_noktalama = {noktalama for noktalama in string.punctuation if noktalama in metin}
            metin = metin.translate(str.maketrans('', '', string.punctuation))
            noktalama_isaretleri_silindi[kategori + "/" + dosya] = list(silinen_noktalama)
            kelimeler = metin.split()
            kelimeler = [kelime.strip(string.punctuation + " ") for kelime in kelimeler]
            a.append(kelimeler)
            # Örnek olarak, temizlenmiş metni göster
            if kategori == "magazin" and magazin_ilk_metin is None:
                magazin_ilk_metin = orijinal_metin  # Orijinal metni kullan
                temizlenmis_metin = metin.translate(str.maketrans('', '', string.punctuation))
                kelimeler = temizlenmis_metin.split()
                magazin_ilk_temizlenmis_metin = ' '.join(kelimeler)
                # Orijinal ve temizlenmiş metni göster
                print("Orijinal Metin (Noktalama İşaretleri Korumalı):")
                print(magazin_ilk_metin)
                print("\nTemizlenmiş Metin (Noktalama İşaretleri Kaldırılmış):")
                print(magazin_ilk_temizlenmis_metin)

# Hangi kategoride ve hangi metinde hangi noktalama işaretleri silindiğini göster
with open('output.txt', 'w', encoding='utf-8') as dosya:
    for dosya_adi, silinenler in noktalama_isaretleri_silindi.items():
        dosya.write(f"{dosya_adi}: {silinenler}\n")

# İkinci kod parçacığını buraya ekleyelim
import os
import string
from collections import defaultdict

kategori_klasorleri = ["magazin", "saglik", "ekonomi", "siyasi", "spor"]
veri_kok_dizini = "1150Haber/r"  # Ana veri klasörü

sayilar_silindi = defaultdict(list)

for kategori in kategori_klasorleri:
    kategori_yolu = os.path.join(veri_kok_dizini, "raw_texts", kategori)
    dosyalar = os.listdir(kategori_yolu)
    for dosya in dosyalar:
        dosya_yolu = os.path.join(kategori_yolu, dosya)
        with open(dosya_yolu, "r") as f:
            metin = f.read().lower()
            silinen_sayilar = [sayi for sayi in metin if sayi.isdigit()]
            metin = ''.join([karakter for karakter in metin if not karakter.isdigit()])
            sayilar_silindi[kategori + "/" + dosya] = silinen_sayilar

# Hangi kategoride ve hangi metinde hangi sayıların silindiğini göster
with open('sayilar_output.txt', 'w', encoding='utf-8') as dosya:
    for dosya_adi, silinen_sayilar in sayilar_silindi.items():
        dosya.write(f"{dosya_adi}: {silinen_sayilar}\n")