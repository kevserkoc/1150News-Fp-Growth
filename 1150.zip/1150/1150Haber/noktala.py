import string
from mlxtend.frequent_patterns import fpgrowth
from mlxtend.preprocessing import TransactionEncoder
import os
import pandas as pd
import chardet  # chardet kütüphanesini ekleyin

def preprocess_text(text):
    # Küçük harfe dönüştürme
    text = text.lower()
    # Noktalama işaretlerini çıkartma
    translator = str.maketrans('', '', string.punctuation)
    text_without_punctuation = text.translate(translator)
    return text_without_punctuation

# Kategoriler ve dosya isimleri
kategori_klasorleri = ["magazin", "saglik", "ekonomi", "siyasi", "spor"]
veri_kok_dizini = "1150Haber/r"  # Ana veri klasörü

kategori_metinleri = {kategori: [] for kategori in kategori_klasorleri}

# Her kategorideki metinleri okuma ve kategorilere göre ayırma
for kategori in kategori_klasorleri:
    kategori_yolu = os.path.join(veri_kok_dizini, "raw_texts", kategori)
    dosyalar = os.listdir(kategori_yolu)
    for dosya in dosyalar:
        dosya_yolu = os.path.join(kategori_yolu, dosya)

        # Dosyanın kodlamasını belirleme
        with open(dosya_yolu, 'rb') as f:
            result = chardet.detect(f.read())
            encoding = result['encoding']

        # Dosyayı belirlenen kodlama ile açma ve ön işlemden geçirme
        with open(dosya_yolu, "r", encoding=encoding) as f:
            original_text = f.read()
            preprocessed_text = preprocess_text(original_text)
            kelimeler = preprocessed_text.split()
            kategori_metinleri[kategori].append((original_text, preprocessed_text, kelimeler))

# Her kategori için TransactionEncoder'a uygun formata getirme
kategori_df = {}
for kategori, metinler in kategori_metinleri.items():
    te = TransactionEncoder()
    te_ary = te.fit_transform([metin[2] for metin in metinler])
    df = pd.DataFrame(te_ary, columns=te.columns_)
    kategori_df[kategori] = df

# Her kategori için FP-Growth algoritması ile sık kalıpları bulma
frequent_itemsets_kategoriler = {}
for kategori, df in kategori_df.items():
    frequent_itemsets_kategoriler[kategori] = fpgrowth(df, min_support=0.5, use_colnames=True, max_len=4)

# Her kategori için sonuçları yazdırma
for kategori, frequent_itemsets in frequent_itemsets_kategoriler.items():
    print(f"--- {kategori} Kategorisi ---")
    print(frequent_itemsets)
    print("\n")
    for metin in kategori_metinleri[kategori]:
        print(f"Orijinal Metin: {metin[0]}")
        print(f"Ön İşlemden Geçirilmiş Metin: {metin[1]}")
        print(f"Kelimeler: {metin[2]}")
        print("---------------\n")
